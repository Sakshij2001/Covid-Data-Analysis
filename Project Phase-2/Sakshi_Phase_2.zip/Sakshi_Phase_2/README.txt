Group 4
Sakshi Patel		




-Project Phase-2 folder contain Five files:
1. Report_Sakshi.docx
2. Report_Sakshi.pdf
3. Sakshi_Project_Phase_2.ipynb
4. Sakshi_Project_Phase_2.pdf
5. super_covid19_dataframe.csv




1. Report_Sakshi.docx
-> This file is my individual work report in .docx type format.

2. Report_Sakshi.pdf
-> This file is my individual work report in .pdf type format.

3. Sakshi_Project_Phase_2.ipynb
-> This file is my project code in .ipynb type format.
-> To run the Sakshi_Project_Phase_2.ipynb file:
	-Click on the 'Upload' button in the Jupyter Notebook interface.
	-Select the Sakshi_Project_Phase_2.ipynb file from your local system. Once the files is uploaded, you can see my work.
	-Or you can directly open it in VS Code.
 
4. Sakshi_Project_Phase_2.pdf
-> This file is my project code in .pdf type format.

5. super_covid19_dataframe.csv
-> This file is dataset(.csv) on which I need to perform tasks .