Group 4
Name: Sakshi Patel


-This folder contain seven files:
1. Sakshi_JupyterNotebook.ipynb
2. Sakshi_JupyterNotebook.pdf
3. Sakshi_report.pdf
4. Sakshi_report.docx
5. ACS Demographic and Housing Estimates.csv
6. ACS Demographic and Housing Estimates_Variable dictionary.csv
7. MergeData_COVID-19data_with_Enrichmentdata.csv
8. super_covid19_dataframe.csv

1. Sakshi_JupyterNotebook.ipynb
-> This is .ipynb type file. This file contain my individual work on different datasets.
-> To run the Sakshi_JupyterNotebook.ipynb file:
	-Click on the 'Upload' button in the Jupyter Notebook interface.
	-Select the Sakshi_JupyterNotebook.ipynb file from your local system. Once the files is uploaded, you can see my work.
	-Or you can directly open it in VS Code.
	 
2. Sakshi_JupyterNotebook.pdf
-> This file is pdf type format of my individual work.

3. Sakshi_report.pdf
-> This file is my individual project report in pdf type format.

4. Sakshi_report.docx
-> This file is my individual project report in word type format.

5. ACS Demographic and Housing Estimates.csv
-> This is my Enrichment dataset: ACS Demographic and HousingEstimates.csv

6. ACS Demographic and Housing Estimates_Variable dictionary.csv
-> This is Vriable dictionary which show the data types of all columns of ACS Demographic and Housing Estimates.csv dataset

7. MergeData_COVID-19data_with_Enrichmentdata.csv
-> This file is the result of Merging the COVID-19 data with Enrichment data.

8. super_covid19_dataframe.csv
-> This dataset is result of merging of three dataset which are COVID deaths, COVID cases and population.