This folder has one folder and three files.

1. Data folder
2. super_covid_data_creation.ipynb
3. super_covid19_dataframe.csv
4. Stage_I_Report.pdf

1. Data folder
-> This folder have three data files which are about COVID deaths, COVID cases and Population.

2. super_covid_data_creation.ipynb
-> This is jupeter notebook file which include some information about three dataset and merging this all dataset into one data file which is super_covid19_dataframe.csv.

3. super_covid19_dataframe.csv
-> This is result of merging COVID deaths, COVID cases and Population dataset.

4. Stage_I_Report.pdf
-> This is our group report.