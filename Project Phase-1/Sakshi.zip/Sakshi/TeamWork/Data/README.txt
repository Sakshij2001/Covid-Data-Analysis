This folder contain three data files.

1. covid_deaths_usafacts.csv
2. covid_confirmed_usafacts.csv
3. covid_county_population_usafacts.csv


1. covid_deaths_usafacts.csv
-> It's covid deaths dataset.

2. covid_confirmed_usafacts.csv
-> It's covid confirmed cases dataset.

3. covid_county_population_usafacts.csv
-> It's county population dataset.